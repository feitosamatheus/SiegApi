﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Sieg.API.Models;
using Sieg.Application.Dtos;
using Sieg.Application.Interfaces;
using System.Threading;
using System.Xml;

namespace Sieg.API.Controllers;

[Route("api/documentos-fiscais")]
public class DocumentosFiscaisController : ControllerBase
{
    private readonly IDocumentoFiscalService _documentoFiscalService;

    public DocumentosFiscaisController(IDocumentoFiscalService documentoFiscalService)
    {
        _documentoFiscalService = documentoFiscalService;
    }

    [HttpPost("upload")]
    [Consumes("multipart/form-data")]
    public async Task<IActionResult> Upload([FromForm] ArquivoUploadRequest request, CancellationToken cancellation)
    {
        var arquivo = request.Arquivo;

        if (arquivo == null || Path.GetExtension(arquivo.FileName).ToLower() != ".xml")
            return BadRequest("Arquivo inválido. Apenas XML é permitido.");

        using var mem = new MemoryStream();
        await arquivo.CopyToAsync(mem, cancellation);
        mem.Position = 0;

        var dto = new ArquivoUploadDTO(arquivo.FileName, arquivo.ContentType, mem, arquivo.Length);

        var resultado = await _documentoFiscalService.UploadDocumentoFiscalAsync(dto, cancellation);

        if (!resultado.Sucesso)
            return BadRequest(new { message = resultado.Mensagem });

        return CreatedAtAction("api/documentos-fiscais/{id}", new { id = resultado.DocumentoFiscal?.Id }, resultado.DocumentoFiscal);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(Guid id, CancellationToken cancellationToken)
    {
        var resultado = await _documentoFiscalService.GetDocumentoByIdAsync(id, cancellationToken);
        if (!resultado.Success)
        {
            if (resultado.Message.Contains("encontrado", StringComparison.OrdinalIgnoreCase))
                return BadRequest(new { message = resultado.Message });

            return StatusCode(500, new { message = resultado.Message });
        }

        return Ok(resultado.DocumentoFiscal);
    }

    // GET /documentos-fiscais
    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] FiltroDocumentoRequest request, CancellationToken cancellationToken)
    {
        var filtroDto = new FiltroDocumentoDTO(
            CnpjEmitente: request.CnpjEmitente,
            UfEmitente: request.UfEmitente,
            DataInicio: request.DataInicio,
            DataFim: request.DataFim,
            Page: request.Page,
            PageSize: request.PageSize
        );

        var resultado = await _documentoFiscalService.GetAllDocumentosAsync(filtroDto, cancellationToken);

        if (!resultado.Success)
        {
            return StatusCode(500, new { message = resultado.Message });
        }

        return Ok(resultado.DocumentoFiscalPagedDTO);
    }



    //// PUT /documentos-fiscais/{id}
    //[HttpPut("{id}")]
    //public async Task<IActionResult> Update(Guid id, [FromBody] DocumentoFiscal dto)
    //{
    //    var doc = await _context.DocumentosFiscais.FindAsync(id);
    //    if (doc == null) return NotFound();

    //    doc.TipoDocumento = dto.TipoDocumento;
    //    doc.CnpjEmitente = dto.CnpjEmitente;
    //    doc.DataEmissao = dto.DataEmissao;
    //    doc.UfEmitente = dto.UfEmitente;
    //    doc.ValorTotal = dto.ValorTotal;

    //    await _context.SaveChangesAsync();

    //    return Ok(doc);
    //}

    //// DELETE /documentos-fiscais/{id}
    //[HttpDelete("{id}")]
    //public async Task<IActionResult> Delete(Guid id)
    //{
    //    var doc = await _context.DocumentosFiscais.FindAsync(id);
    //    if (doc == null) return NotFound();

    //    if (System.IO.File.Exists(doc.CaminhoXml))
    //        System.IO.File.Delete(doc.CaminhoXml);

    //    _context.DocumentosFiscais.Remove(doc);
    //    await _context.SaveChangesAsync();

    //    return NoContent();
    //}
}
