﻿namespace Sieg.API.Models;

public class ArquivoUploadRequest
{
    public IFormFile Arquivo { get; set; } = default!;
}
