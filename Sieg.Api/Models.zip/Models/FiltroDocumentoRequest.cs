﻿namespace Sieg.API.Models;

public class FiltroDocumentoRequest
{
    public string? CnpjEmitente { get; init; }
    public string? UfEmitente { get; init; }
    public DateTime? DataInicio { get; init; }
    public DateTime? DataFim { get; init; }
    public int Page { get; init; } = 1;
    public int PageSize { get; init; } = 20;
}
